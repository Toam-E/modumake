import { useState } from "react";
import { Button } from "@/components/ui/button";
import ModumakeDemo from "@/components/ModumakeDemo";

const Index = () => {
  return <ModumakeDemo />;
};

export default Index;
